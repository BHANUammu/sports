package com.sports.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sports.dto.AddSports;
import com.sports.dto.Admin;
import com.sports.dto.user;
import com.sports.service.ServiceClass;

@WebServlet("/user")
public class Userservlet extends HttpServlet{
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		
		int teamId = Integer.parseInt(req.getParameter("teamId"));
		String teamName = req.getParameter("teamName");
		
	
		user user = new user();
		
		ServiceClass sc = new ServiceClass();
		
		user.setTeamId(teamId);
		user.setTeamName(teamName);
		

		
		boolean u = sc.register(user);
		
		System.out.println(u);
		
		if(u) 
		{
		
				System.out.println("register successful");
				resp.sendRedirect("./home.html");

			
		}else {
			//Login Failed
			System.out.println(" Failed");
			resp.sendRedirect("./login.html");
		}
		
	}

	private String String(String parameter) {
		// TODO Auto-generated method stub
		return null;
	}

}
