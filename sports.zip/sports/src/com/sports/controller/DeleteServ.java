package com.sports.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sports.dto.Admin;
import com.sports.service.ServiceClass;

@WebServlet("/deleteevent")
public class DeleteServ extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		
		int  teamId = Integer.parseInt(req.getParameter("teamId"));
		
		ServiceClass sc = new ServiceClass();
		
		
		boolean b = sc.delete(teamId);
		
		if(b)
		{
			HttpSession session=req.getSession();
			System.out.println("event deleted");
			resp.sendRedirect("./addevent.html");
			
			
		}
		else
		{
			System.out.println("failed");
			resp.sendRedirect("./Delete.html");
			
			
		}
	}
}
