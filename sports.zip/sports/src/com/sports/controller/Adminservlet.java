package com.sports.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sports.dto.Admin;
import com.sports.service.ServiceClass;

@WebServlet("/admin")
public class Adminservlet extends HttpServlet
{
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		String userName = req.getParameter("userName");
		String password = req.getParameter("password");
		
		Admin admin = new Admin();
		ServiceClass sc = new ServiceClass();
		admin.setUserName(userName);
		admin.setPassword(password);
		

		
		Admin a = sc.login(userName,password);
		System.out.println(a);
		
		if(a!=null) {
		
				System.out.println("login successful");
				resp.sendRedirect("./addevent.html");

			
		}else {
			//Login Failed
			System.out.println("Login Failed");
			resp.sendRedirect("./login.html");
		}
		
	}
}
