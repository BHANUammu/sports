package com.sports.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sports.dto.AddSports;
import com.sports.dto.Admin;
import com.sports.service.ServiceClass;

@WebServlet("/addSports")
public class AddSportsservlet extends HttpServlet{
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{	
		int teamId = Integer.parseInt(req.getParameter("teamId"));
		String sportsName = req.getParameter("sportsname");
		String date = req.getParameter("date");
		String venue = req.getParameter("venue");
		int fees = Integer.parseInt(req.getParameter("fees"));
		int firstprice = Integer.parseInt(req.getParameter("1stprice"));
		int secondprice = Integer.parseInt(req.getParameter("2ndprice"));
		int thirdprice = Integer.parseInt(req.getParameter("3rdprice"));
		
		AddSports addsports = new AddSports();
		
		ServiceClass sc = new ServiceClass();
		
		addsports.setTeamId(teamId);
		addsports.setSportsname(sportsName);
		addsports.setDate(date);
		addsports.setVenue(venue);
		addsports.setFees(fees);
		addsports.setFirstprice(firstprice);
		addsports.setSecondprice(secondprice);
		addsports.setThirdprice(thirdprice);
		

		
		boolean as = sc.addEvents(addsports);
		
		System.out.println(as);
		
		if(as) 
		{
		
				System.out.println("sports successful");
				resp.sendRedirect("./addevent.html");

			
		}else {
			//Login Failed
			System.out.println(" Failed");
			resp.sendRedirect("./login.html");
		}
		
	}

}
