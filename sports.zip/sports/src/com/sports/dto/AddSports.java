package com.sports.dto;

public class AddSports 
{ private int teamId;
	public int getTeamId() {
	return teamId;
}

public void setTeamId(int teamId) {
	this.teamId = teamId;
}

	private String sportsname;
	
	private String date;
	
	private String venue;
	
	private int fees;

	private int firstprice;
	
	private int secondprice;
	
	private int thirdprice;

	public String getSportsname() {
		return sportsname;
	}

	public void setSportsname(String sportsname) {
		this.sportsname = sportsname;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getVenue() {
		return venue;
	}

	public void setVenue(String venue) {
		this.venue = venue;
	}

	public int getFees() {
		return fees;
	}

	public void setFees(int fees) {
		this.fees = fees;
	}

	public int getFirstprice() {
		return firstprice;
	}

	public void setFirstprice(int firstprice) {
		this.firstprice = firstprice;
	}

	public int getSecondprice() {
		return secondprice;
	}

	public void setSecondprice(int secondprice) {
		this.secondprice = secondprice;
	}

	public int getThirdprice() {
		return thirdprice;
	}

	public void setThirdprice(int thirdprice) {
		this.thirdprice = thirdprice;
	}

	@Override
	public String toString() {
		return "AddSports [teamId=" + teamId + ", sportsname=" + sportsname + ", date=" + date + ", venue=" + venue
				+ ", fees=" + fees + ", firstprice=" + firstprice + ", secondprice=" + secondprice + ", thirdprice="
				+ thirdprice + ", getTeamId()=" + getTeamId() + ", getSportsname()=" + getSportsname() + ", getDate()="
				+ getDate() + ", getVenue()=" + getVenue() + ", getFees()=" + getFees() + ", getFirstprice()="
				+ getFirstprice() + ", getSecondprice()=" + getSecondprice() + ", getThirdprice()=" + getThirdprice()
				+ "]";
	}

	
	
	
	
}
