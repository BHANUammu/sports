package com.sports.service;



import com.sports.dao.Admindaoclass;
import com.sports.dao.Admindaoimp;
import com.sports.dto.AddSports;
import com.sports.dto.Admin;
import com.sports.dto.user;


public class ServiceClass {
	
	public Admin login(String username, String password){

		Admindaoimp dao = new Admindaoclass();

		Admin a = dao.login(username,password);

		return a;

	}
	public boolean addEvents(AddSports addsports ){

		Admindaoimp dao = new Admindaoclass();

		boolean as = dao.AddEvent(addsports);

		return as;

	}

	public boolean register(user user ){

		Admindaoimp dao = new Admindaoclass();

		boolean u = dao.register(user);

		return u;

	}

	
	public boolean add(Admin admin) {
		
		return false;
	}
	
	public boolean delete(int teamId) {
		Admindaoimp dao = new Admindaoclass();

		boolean u = dao.deleteEvent(teamId);

		return u;
		
	}


}
