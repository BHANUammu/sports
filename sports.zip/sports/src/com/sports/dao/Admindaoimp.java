package com.sports.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import com.sports.dto.AddSports;
import com.sports.dto.Admin;
import com.sports.dto.user;


public interface Admindaoimp 
{
	public Admin login(String username, String password);
	
	public boolean AddEvent(AddSports addsports) ;

	public boolean register(user user);

	public boolean deleteEvent(int teamId);
}