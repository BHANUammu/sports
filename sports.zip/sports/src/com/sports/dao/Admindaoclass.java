package com.sports.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.sports.dto.AddSports;
import com.sports.dto.Admin;
import com.sports.dto.user;

public class Admindaoclass implements Admindaoimp{
	
	
	@Override
	public Admin login(String username, String password) {
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		Admin a=null;

		String sql = "select * from admin where username= ? and password=? ";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/sports?user=root&password=root";
			con = DriverManager.getConnection(url);

			
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, username);
			pstmt.setString(2, password);                                     
			
				
		
		rs = pstmt.executeQuery();
		System.out.println(rs);

		if(rs.next()) {
			a=new Admin();

			a.setUserName(rs.getString("username"));
			a.setPassword(rs.getString("password"));
			
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
		finally {
		
	}
		
		
		return a;
	}
	
	@Override
	public boolean AddEvent(AddSports addsports) {
		
		Connection con = null;
		PreparedStatement pstmt = null;
	
	

		String sql = "Insert into addevent values(?,?,?,?,?,?,?,?)";
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/sports?user=root&password=root";
			con = DriverManager.getConnection(url);

			
			pstmt = con.prepareStatement(sql);
			
			pstmt.setInt(1,addsports.getTeamId());
			
			pstmt.setString(2, addsports.getSportsname());
		
			pstmt.setString(3, addsports.getDate()); 
			
			pstmt.setString(4,addsports.getVenue());
			
			pstmt.setInt(5,addsports.getFees());
			
			pstmt.setInt(6, addsports.getFirstprice());
			
			pstmt.setInt(7, addsports.getSecondprice());
	
			pstmt.setInt(8, addsports.getThirdprice());
			
				
		
			int count = pstmt.executeUpdate();
		System.out.println(count);
		if(count>0)
		{
			return true;
		}
		else
		{
			return false;
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
		finally {
		
	}
		
		
		return true;
	}

	

	







@Override
public boolean register(user user) {
	
	Connection con = null;
	PreparedStatement pstmt = null;

	

	String sql = "Insert into registration values(?,?)";
	
	try {
		Class.forName("com.mysql.jdbc.Driver");
		String url = "jdbc:mysql://localhost:3306/sports?user=root&password=root";
		con = DriverManager.getConnection(url);

		
		pstmt = con.prepareStatement(sql);
		
		pstmt.setInt(1, user.getTeamId());
	
		pstmt.setString(2, user.getTeamName()); 
		
		
			
	
		int count = pstmt.executeUpdate();
	System.out.println(count);
	if(count>0)
	{
		return true;
	}
	else
	{
		return false;
	}
} catch (Exception e) {
	e.printStackTrace();
}
	finally {
	
}
	
	
	return true;
}

public boolean deleteEvent(int teamId) {

	Connection con = null;
	PreparedStatement pstmt = null;

	try
	{

		Class.forName("com.mysql.jdbc.Driver");
		String url = "jdbc:mysql://localhost:3306/sports?user=root&password=root";
		con = DriverManager.getConnection(url);

		System.out.println("connected");

		String query = "Delete from addevent where teamId= ?";
		pstmt = con.prepareStatement(query);

		pstmt.setInt(1, teamId);



		System.out.println("deleted");
		int count = pstmt.executeUpdate();

		if(count>0)
		{
			return true;
		}
		else
		{
			return false;
		}

	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	finally
	{
		if(con!=null)
		{
			try {
				con.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}
	}


	return true;
}



}